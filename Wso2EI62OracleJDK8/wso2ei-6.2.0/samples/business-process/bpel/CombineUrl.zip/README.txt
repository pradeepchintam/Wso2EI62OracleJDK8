Display the use of ode:combineUrl xpath function.
This function takes the relative URL and combines it with the base URL to return a new absolute URL.
If the relative parameter is an absolute URL, returns it instead.
