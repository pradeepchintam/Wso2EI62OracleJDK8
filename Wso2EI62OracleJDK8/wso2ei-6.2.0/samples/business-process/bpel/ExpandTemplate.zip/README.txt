This sample demonstrates the use of xpath function expand-template(template, [name, value]*).
This function is similar to composeURL function, but undefined variables are not replaced with an empty string.
They are ignored. As a result with incomplete mapping may return a new URL template.